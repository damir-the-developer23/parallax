import './style.css';
import { MuseumAudio } from './audio.js';

const audio = new MuseumAudio();
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const menuButton = $('#menu-toggle');
const chapterMenu = $('#chapter-menu');
const soundButton = $('#sound-toggle');
const soundLabel = $('.sound-label', soundButton);
const flash = $('#transition-flash');
const toast = $('#toast');
let toastTimer;
let lastChapter = '01';
let curatorClicks = 0;
let lastModalTrigger = null;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2600);
}

function closeMenu() {
  chapterMenu.hidden = true;
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.querySelector('span').textContent = '＋';
}

menuButton.addEventListener('click', () => {
  const opening = chapterMenu.hidden;
  chapterMenu.hidden = !opening;
  menuButton.setAttribute('aria-expanded', String(opening));
  menuButton.querySelector('span').textContent = opening ? '×' : '＋';
  if (audio.enabled) audio.effect('click');
});

$$('.chapter-menu a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('click', event => {
  if (!chapterMenu.hidden && !chapterMenu.contains(event.target) && !menuButton.contains(event.target)) closeMenu();
});

soundButton.addEventListener('click', async () => {
  if (audio.enabled) {
    await audio.disable();
    soundButton.setAttribute('aria-pressed', 'false');
    soundLabel.textContent = 'SOUND OFF';
    soundButton.querySelector('.sound-icon').textContent = '♪';
  } else {
    const success = await audio.enable();
    if (!success) {
      showToast('THIS BROWSER DOES NOT SUPPORT WEB AUDIO');
      return;
    }
    soundButton.setAttribute('aria-pressed', 'true');
    soundLabel.textContent = 'SOUND ON';
    soundButton.querySelector('.sound-icon').textContent = '♫';
  }
});

const chapters = $$('.scene[data-chapter]');
const chapterObserver = new IntersectionObserver(entries => {
  const visible = entries.filter(entry => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
  if (!visible) return;
  const chapter = visible.target.dataset.chapter;
  if (chapter !== lastChapter) {
    lastChapter = chapter;
    document.body.dataset.chapter = chapter;
    $('#current-chapter').textContent = chapter;
    $('#current-label').textContent = visible.target.dataset.label;
    const chapterNumber = Number(chapter) - 1;
    audio.setScene(chapterNumber);
    flash.classList.remove('flash');
    void flash.offsetWidth;
    flash.classList.add('flash');
    if (audio.enabled) audio.effect('transition');
  }
}, { threshold: [0.18, 0.35, 0.55], rootMargin: '-12% 0px -18% 0px' });
chapters.forEach(chapter => chapterObserver.observe(chapter));

const exhibitDetails = {
  phone: {
    kicker: 'OBJECT 001 / TELECOMMUNICATIONS',
    title: 'The Long-Distance Telephone',
    description: 'A Bakelite receiver recovered from apartment 14, Building C. The owner, Mara Venn, was declared dead in 2068. The telephone rang on 12 May 2077. The receiving operator remembers a child asking whether the war had ended. No war is listed in the records for that year.',
    origin: 'Apartment 14 / demolished 2061', verified: '12 MAY 2077 / 03:17', status: 'RANG WHILE DISCONNECTED'
  },
  map: {
    kicker: 'OBJECT 002 / CARTOGRAPHY',
    title: 'The Republic of Veyra',
    description: 'A complete national survey of a country that occupies 41,000 square kilometres of the North Atlantic. Its three borders are listed as France, the Pacific Ocean, and itself. Every copy of the atlas contains a different coastline. The population count remains identical.',
    origin: 'Atlas of Quiet Nations / page 11', verified: 'NEVER / CONTINUOUSLY', status: 'GEOGRAPHICALLY IMPOSSIBLE'
  },
  clock: {
    kicker: 'OBJECT 003 / CHRONOMETRY',
    title: 'The Calendar That Forgot',
    description: 'This clock was found in a railway station whose timetable contained a gap of exactly twenty-four hours. Passengers recall arriving on Monday and leaving on Wednesday. The station master insists Tuesday was never a working day. The date printed on the reverse is 32 / 13 / 1982.',
    origin: 'North Platform / Station 0', verified: '32 DECEMBER 1982', status: 'TIMEKEEPING SUSPENDED'
  },
  portrait: {
    kicker: 'OBJECT 004 / PERSONAL EFFECTS',
    title: 'The Man Who Wasn’t Born',
    description: 'The sitter appears in a photograph taken in 2041. His death certificate was issued in 1933, and the photographer was born in 2050. On the back, in handwriting attributed to the sitter, are the words: “Please do not let them remember me twice.”',
    origin: 'Estate of an unnamed witness', verified: '2041 / NEGATIVE UNDAMAGED', status: 'IDENTITY UNRESOLVED'
  },
  seed: {
    kicker: 'OBJECT 005 / BOTANICAL',
    title: 'The First Last Seed',
    description: 'A single seed recovered from the remains of the Veyran Archive Forest. The fire that destroyed the forest is dated fourteen days before the planting records. Carbon analysis indicates the seed is older than the species it belongs to. It has begun to germinate in complete darkness.',
    origin: 'Veyra / Site of the Former Forest', verified: 'BEFORE THE FIRST PLANTING', status: 'GERMINATING / NO SOIL'
  }
};

const modal = $('#exhibit-modal');
const modalTitle = $('#modal-title');
function openExhibit(key, trigger) {
  const details = exhibitDetails[key];
  if (!details) return;
  lastModalTrigger = trigger;
  $('#modal-kicker').textContent = details.kicker;
  modalTitle.textContent = details.title;
  $('#modal-description').textContent = details.description;
  $('#modal-origin').textContent = details.origin;
  $('#modal-verified').textContent = details.verified;
  $('#modal-status').textContent = details.status;
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
  $('.modal-close', modal).focus();
  audio.effect('click');
}
function closeExhibit() {
  if (modal.hidden) return;
  modal.hidden = true;
  document.body.style.overflow = '';
  if (lastModalTrigger) lastModalTrigger.focus();
}
$$('[data-open]').forEach(button => button.addEventListener('click', () => openExhibit(button.dataset.open, button)));
$$('[data-close-modal]').forEach(element => element.addEventListener('click', closeExhibit));

const unsealButton = $('#unseal-button');
const fileReveal = $('#file-reveal');
unsealButton.addEventListener('click', () => {
  const opening = fileReveal.hidden;
  fileReveal.hidden = !opening;
  unsealButton.innerHTML = opening ? 'FILE OPENED <b>−</b>' : 'UNSEAL THE FILE <b>＋</b>';
  unsealButton.setAttribute('aria-expanded', String(opening));
  audio.effect(opening ? 'reveal' : 'click');
  if (opening) showToast('ACCESS LOGGED. THE ARCHIVE NOTICED.');
});

const curatorAnswer = $('#curator-answer');
$('#ask-curator').addEventListener('click', () => {
  curatorAnswer.hidden = !curatorAnswer.hidden;
  audio.effect(curatorAnswer.hidden ? 'click' : 'answer');
  if (!curatorAnswer.hidden) showToast('A RESPONSE HAS BEEN ADDED TO YOUR FILE.');
});

const roomZero = $('#room-zero');
function openRoomZero() {
  roomZero.hidden = false;
  document.body.style.overflow = 'hidden';
  $('#zero-close').focus();
  audio.effect('door');
}
function closeRoomZero() {
  roomZero.hidden = true;
  document.body.style.overflow = '';
  $('#secret-trigger').focus();
}
$('#secret-trigger').addEventListener('click', openRoomZero);
$('#zero-close').addEventListener('click', closeRoomZero);

const curatorPortrait = $('#curator-portrait');
function inspectCurator() {
  curatorClicks += 1;
  if (curatorClicks === 1) {
    showToast('THE CURATOR LOOKS FAMILIAR.');
    audio.effect('click');
  } else if (curatorClicks === 2) {
    showToast('YOU HAVE SEEN THIS FACE SOMEWHERE ELSE.');
    audio.effect('answer');
  } else {
    curatorClicks = 0;
    openRoomZero();
  }
}
curatorPortrait.addEventListener('click', inspectCurator);
curatorPortrait.addEventListener('keydown', event => {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    inspectCurator();
  }
});

$('#leave-button').addEventListener('click', () => {
  audio.effect('door');
  showToast('EXIT RECORDED. ARRIVAL IS STILL PENDING.');
  window.setTimeout(() => $('#entrance').scrollIntoView({ behavior: 'smooth' }), 420);
});

// Keep the dialogue and secret-room overlays keyboard-accessible.
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    if (!roomZero.hidden) closeRoomZero();
    else if (!modal.hidden) closeExhibit();
    else if (!chapterMenu.hidden) closeMenu();
  }
});

// A little analog motion in the impossible stairwell, kept subtle on touch devices.
const stairwell = $('.stairwell');
if (stairwell && window.matchMedia('(pointer:fine)').matches && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  window.addEventListener('pointermove', event => {
    const x = (event.clientX / window.innerWidth - 0.5) * 5;
    const y = (event.clientY / window.innerHeight - 0.5) * -5;
    stairwell.style.setProperty('--pointer-x', `${x}deg`);
    stairwell.style.setProperty('--pointer-y', `${y}deg`);
  }, { passive: true });
}

// Initial chapter state is explicit so the index is correct before the first scroll event.
document.body.dataset.chapter = '01';
$('#current-chapter').textContent = '01';
$('#current-label').textContent = 'THE ENTRANCE';
