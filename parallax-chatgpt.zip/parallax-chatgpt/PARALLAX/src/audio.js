export class MuseumAudio {
  constructor() {
    this.context = null;
    this.master = null;
    this.ambient = null;
    this.enabled = false;
    this.sceneIndex = 0;
  }

  async enable() {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return false;
    if (!this.context) this.#createContext(AudioContextClass);
    if (this.context.state === 'suspended') await this.context.resume();
    this.enabled = true;
    this.master.gain.cancelScheduledValues(this.context.currentTime);
    this.master.gain.setTargetAtTime(0.72, this.context.currentTime, 0.18);
    this.#setAtmosphere(this.sceneIndex);
    this.effect('wake');
    return true;
  }

  async disable() {
    if (!this.context || !this.enabled) return;
    this.enabled = false;
    this.master.gain.cancelScheduledValues(this.context.currentTime);
    this.master.gain.setTargetAtTime(0, this.context.currentTime, 0.12);
  }

  #createContext(AudioContextClass) {
    this.context = new AudioContextClass();
    this.master = this.context.createGain();
    this.master.gain.value = 0;
    this.master.connect(this.context.destination);

    const lowpass = this.context.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 240;
    lowpass.Q.value = 0.7;
    lowpass.connect(this.master);

    this.ambient = [];
    [55, 82.41, 110].forEach((frequency, index) => {
      const oscillator = this.context.createOscillator();
      const gain = this.context.createGain();
      oscillator.type = index === 2 ? 'triangle' : 'sine';
      oscillator.frequency.value = frequency;
      gain.gain.value = [0.13, 0.055, 0.025][index];
      oscillator.connect(gain).connect(lowpass);
      oscillator.start();
      this.ambient.push({ oscillator, gain });
    });
  }

  #setAtmosphere(sceneIndex) {
    if (!this.context || !this.enabled) return;
    const palettes = [
      [55, 82.41, 110], [65.41, 98, 130.81], [43.65, 65.41, 87.31],
      [73.42, 110, 146.83], [38.89, 58.27, 77.78], [49, 73.42, 98], [55, 82.41, 123.47]
    ];
    const frequencies = palettes[Math.max(0, Math.min(6, sceneIndex))];
    this.ambient.forEach((voice, index) => {
      voice.oscillator.frequency.setTargetAtTime(frequencies[index], this.context.currentTime, 0.45);
    });
  }

  setScene(sceneIndex) {
    this.sceneIndex = sceneIndex;
    this.#setAtmosphere(sceneIndex);
  }

  effect(kind = 'click') {
    if (!this.enabled || !this.context) return;
    const now = this.context.currentTime;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    const filter = this.context.createBiquadFilter();
    const presets = {
      wake: { from: 190, to: 420, duration: 0.42, volume: 0.14, type: 'sine' },
      click: { from: 620, to: 410, duration: 0.09, volume: 0.055, type: 'sine' },
      reveal: { from: 120, to: 720, duration: 0.65, volume: 0.12, type: 'triangle' },
      transition: { from: 92, to: 36, duration: 0.48, volume: 0.11, type: 'sawtooth' },
      door: { from: 240, to: 74, duration: 0.8, volume: 0.13, type: 'triangle' },
      answer: { from: 330, to: 165, duration: 0.56, volume: 0.09, type: 'sine' }
    };
    const preset = presets[kind] || presets.click;
    oscillator.type = preset.type;
    oscillator.frequency.setValueAtTime(preset.from, now);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(1, preset.to), now + preset.duration);
    filter.type = 'lowpass';
    filter.frequency.value = kind === 'transition' ? 420 : 1800;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(preset.volume, now + 0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + preset.duration);
    oscillator.connect(filter).connect(gain).connect(this.master);
    oscillator.start(now);
    oscillator.stop(now + preset.duration + 0.03);
  }
}
