# PARALLAX — The Museum of Everything That Never Happened

An experimental, scroll-driven museum of impossible artefacts and contradictory histories. Built with Vite, vanilla JavaScript, CSS, and the Web Audio API.

## Run locally

Requirements: Node.js 18+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (normally `http://localhost:5173/`).

## Production build

```bash
npm run build
npm run preview
```

The production site is generated in `dist/`.

## Interactions

- Use **INDEX** in the top-right corner to jump between the seven chapters.
- Open each exhibit with **EXAMINE OBJECT** to read its archive record.
- Turn **SOUND ON** on to enable the generated ambient drone and interaction cues. Audio is opt-in and uses the Web Audio API; no sound file is downloaded.
- Unseal the restricted file in chapter five.
- Ask the curator a question in chapter six.
- Click the curator portrait three times, or use the small `0` control in the final chapter, to discover Room Zero.
- Press `Escape` to close overlays.

## Notes

- No UI framework or template is used; the artwork is made from CSS, SVG, and HTML.
- `prefers-reduced-motion` is respected.
- `node_modules/` and the production `dist/` output are excluded from the source ZIP.
