let c,out,nodes=[],cur=1,muted=false;
const D=[0,[[55,'sine',.12],[82.4,'sine',.08]],[[130.8,'triangle',.05],[196,'sine',.05]],[[36.7,'sine',.2],[38,'sine',.2],[220,'sine',.01]],[[55,'sawtooth',.03],[55.7,'sawtooth',.03]],[[98,'sine',.07],[138.6,'sine',.07],[146.8,'triangle',.05]],[[73.4,'sine',.1],[110,'sine',.07]],[[440,'sine',.05],[441,'sine',.05]]];
const osc=(f,t,v)=>{const o=c.createOscillator(),g=c.createGain();o.type=t;o.frequency.value=f;g.gain.value=0;g.gain.linearRampToValueAtTime(v,c.currentTime+1);o.connect(g).connect(out);o.start();return[o,g]};
const tone=(f,d,t='sine',v=.15,f2)=>{if(!c)return;const o=c.createOscillator(),g=c.createGain(),n=c.currentTime;o.type=t;o.frequency.setValueAtTime(f,n);f2&&o.frequency.exponentialRampToValueAtTime(f2,n+d);g.gain.setValueAtTime(v,n);g.gain.exponentialRampToValueAtTime(.0001,n+d);o.connect(g).connect(out);o.start();o.stop(n+d)};
export const A={
init(){if(!c){c=new(window.AudioContext||window.webkitAudioContext)();out=c.createGain();out.gain.value=muted?0:.6;out.connect(c.destination)}c.state==='suspended'&&c.resume();this.stage(cur)},
stage(n){cur=n;if(!c)return;nodes.forEach(([o,g])=>{g.gain.linearRampToValueAtTime(0,c.currentTime+.5);o.stop(c.currentTime+.6)});nodes=D[n].map(a=>osc(...a))},
click(){tone(880,.1,'triangle',.12)},tick(){tone(300,.04,'square',.04)},chime(){tone(660,.8,'sine',.12);tone(990,1,'sine',.08)},
whoosh(){if(!c)return;const b=c.createBuffer(1,c.sampleRate,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;const s=c.createBufferSource(),f=c.createBiquadFilter(),g=c.createGain(),n=c.currentTime;s.buffer=b;f.type='bandpass';f.frequency.setValueAtTime(200,n);f.frequency.exponentialRampToValueAtTime(4000,n+.8);g.gain.setValueAtTime(.3,n);g.gain.exponentialRampToValueAtTime(.001,n+1);s.connect(f).connect(g).connect(out);s.start()},
glitch(){for(let i=0;i<8;i++)setTimeout(()=>tone(100+Math.random()*1500,.07,'sawtooth',.08),i*60)},
toggle(){muted=!muted;out&&(out.gain.value=muted?0:.6);return!muted}};
